package com.basic.springbootbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
